# Changelog

## 1.0.0
- Initial release
- Unit conversion categories: Length, Weight, Temperature, Area, Speed, Data (bytes)
- Live reading of selected cell value
- Replace cell or insert result to the right
- Swap units button
- Theme support (light/dark)
