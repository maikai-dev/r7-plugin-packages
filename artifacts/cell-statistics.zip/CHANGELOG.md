# Changelog

## 1.0.0
- Initial release
- Real-time statistics for selected cells (sum, average, min, max, median, standard deviation)
- Count of total, numeric, and empty cells
- Theme support (light/dark)
