# Changelog

## 1.0.0
- Initial release
- Text case transformations: UPPERCASE, lowercase, Title Case, Sentence case
- Clean up operations: Trim spaces, Clean non-printable characters, Reverse text, Remove duplicates
- Add prefix/suffix to cells
- Theme support (light/dark)
