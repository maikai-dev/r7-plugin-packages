# Changelog

## 1.0.0
- Initial release
- Data types: Random Integers, Decimals, Number Sequences, Dates, UUID, Names, Emails, Passwords, Lorem Ipsum
- Configurable range, count, and insertion direction (down/right)
- Theme support (light/dark)
